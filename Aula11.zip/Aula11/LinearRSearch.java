public class LinearRSearch {

    public int search(double[] array, double target, int index){
        if(index >= array.length){
            return -1;
        }
        if(array[index] == target){
            return index;
        }
        return search(array, target, index + 1);
    }
}