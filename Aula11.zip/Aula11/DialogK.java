import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DialogK extends JDialog implements ActionListener{
    JLabel lb;
    JTextField tf;
    JButton bt;
    double value;

    public DialogK(JFrame fr){
        super(fr,true);
        Container cp = getContentPane();
        cp.setLayout(new FlowLayout());
        lb = new JLabel("Key: ");
        cp.add(lb);
        tf = new JTextField(10);
        cp.add(tf);
        bt = new JButton("OK");
        cp.add(bt);
        bt.addActionListener(this);
        setSize(200,100);
        setLocation(200,200);
        setTitle("Search Key");
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == bt){
            value = Double.parseDouble(tf.getText());
            dispose();
        }
    }

    static double getValue(JFrame fr){
        DialogK di = new DialogK(fr);
        return di.value;
    }
}