public class LinearISearch{

    public int search(double[] array, double target){
        for(int i = 0; i < array.length; i++){
            if (array[i] == target) {
                return i;
            }
        }
        return -1;
    }
}