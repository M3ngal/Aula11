public class BinaryRSearch {

    public static int search(double[] array, double key, int left, int right){
        if(left > right){
            return -1; // Retorna -1 se a chave não for encontrada
        }

        int mid = left + (right - left) / 2;

        if(array[mid] == key){
            return mid;
        }
        else if(array[mid] < key){
            return search(array, key, mid + 1, right);
        }
        else{
            return search(array, key, left, mid - 1);
        }
    }
}