import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.*;

public class MenuFrame extends JFrame {
    private double[] a;
    QuickSort sorter = new QuickSort();
    private JLabel displayJLabel;

    public MenuFrame() {
        super("Array Manager");
        JMenuBar bar = new JMenuBar();
        setJMenuBar(bar);
        JFrame fr = new JFrame();

        JMenu arrayMenu = new JMenu("Array");
        arrayMenu.setMnemonic(0);

        JMenuItem dimItem = new JMenuItem("Dimension");
        dimItem.setMnemonic(1);
        arrayMenu.add(dimItem);
        dimItem.addActionListener(event -> a = new double[DialogInt.getValue(fr)]);

        JMenuItem typeItem = new JMenuItem("Type");
        typeItem.setMnemonic(2);
        arrayMenu.add(typeItem);
        typeItem.addActionListener(event -> {
            if (a != null) {
                for (int i = 0; i < a.length; i++) {
                    a[i] = DialogDbl.getValue(fr);
                }
            }
        });

        JMenuItem showItem = new JMenuItem("Show");
        showItem.setMnemonic(3);
        arrayMenu.add(showItem);
        showItem.addActionListener(event -> {
            if (a != null) {
                String vec = "";
                for (int i = 0; i < a.length; i++) {
                    vec += String.format("%.2f  ", a[i]);
                }
                displayJLabel.setText(vec);
            }
        });
        bar.add(arrayMenu);

        JMenu probestMenu = new JMenu("PROBEST");
        probestMenu.setMnemonic(4);

        JMenuItem avItem = new JMenuItem("Avarage");
        avItem.setMnemonic(5);
        probestMenu.add(avItem);
        avItem.addActionListener(event -> {
            if (a != null) {
                double z = 0;
                for (int i = 0; i < a.length; i++) {
                    z += a[i];
                }
                z = z / a.length;
                displayJLabel.setText("Σx/n = " + z);
            }
        });

        JMenuItem sdevItem = new JMenuItem("Standard Deviation");
        sdevItem.setMnemonic(6);
        probestMenu.add(sdevItem);
        sdevItem.addActionListener(event -> {
            if (a != null) {
                double z = 0;
                double z1 = 0;
                for (int i = 0; i < a.length; i++) {
                    z += a[i];
                }
                z = z / a.length;
                for (int i = 0; i < a.length; i++) {
                    z1 += Math.pow(a[i] - z, 2);
                }
                z1 = Math.sqrt(z1 / a.length);
                displayJLabel.setText("√[Σ(x-x')²/n] = " + z1);
            }
        });

        JMenuItem varItem = new JMenuItem("Variance");
        varItem.setMnemonic(7);
        probestMenu.add(varItem);
        varItem.addActionListener(event -> {
            if (a != null) {
                double z = 0;
                double z1 = 0;
                for (int i = 0; i < a.length; i++) {
                    z += a[i];
                }
                z = z / a.length;
                for (int i = 0; i < a.length; i++) {
                    z1 += Math.pow(a[i] - z, 2);
                }
                z1 = z1 / a.length;
                displayJLabel.setText("Σ(x-x')²/n = " + z1);
            }
        });

        JMenuItem medItem = new JMenuItem("Median");
        medItem.setMnemonic(8);
        probestMenu.add(medItem);
        medItem.addActionListener(event -> {
            if (a != null) {
                double med = 0;
                double b[] = a.clone();
                sorter.sort(b);
                if (b.length % 2 == 0) {
                    med = (b[(b.length / 2) - 1] + b[b.length / 2]) / 2;
                    displayJLabel.setText("((n/2)th term + (n/2 + 1)th term)/2 = " + med);
                } else {
                    med = b[b.length / 2];
                    displayJLabel.setText("(n/2)th term = " + med);
                }
            }
        });

        JMenuItem casItem = new JMenuItem("Asymmetry Coefficient");
        casItem.setMnemonic(9);
        probestMenu.add(casItem);
        casItem.addActionListener(event -> {
            if (a != null) {
                double z = 0;
                double z1 = 0;
                double med = 0;
                double b[] = a.clone();
                sorter.sort(b);
                for (int i = 0; i < a.length; i++) {
                    z += a[i];
                }
                z = z / a.length;
                for (int i = 0; i < a.length; i++) {
                    z1 += Math.pow(a[i] - z, 2);
                }
                z1 = Math.sqrt(z1 / a.length);
                if (b.length % 2 == 0) {
                    med = (b[(b.length / 2) - 1] + b[b.length / 2]) / 2;
                } else {
                    med = b[b.length / 2];
                }
                double ca = 3 * (z - med) / z1;
                displayJLabel.setText("3(x' - med)/s = " + ca);
            }
        });

        JMenuItem cvItem = new JMenuItem("Variation Coefficient");
        cvItem.setMnemonic(10);
        probestMenu.add(cvItem);
        cvItem.addActionListener(event -> {
            if (a != null) {
                double z = 0;
                double z1 = 0;
                for (int i = 0; i < a.length; i++) {
                    z += a[i];
                }
                z = z / a.length;
                for (int i = 0; i < a.length; i++) {
                    z1 += Math.pow(a[i] - z, 2);
                }
                z1 = Math.sqrt(z1 / a.length);
                double cv = (z1 / z) * 100;
                displayJLabel.setText("s/x' = " + cv + "%");
            }
        });
        bar.add(probestMenu);

        JMenu cdiMenu = new JMenu("CDI");
        cdiMenu.setMnemonic(11);

        JMenuItem fuItem = new JMenuItem("Function");
        fuItem.setMnemonic(12);
        cdiMenu.add(fuItem);
        fuItem.addActionListener(event -> {
            if (a != null) {
                StringBuilder vec = new StringBuilder();
                int n = a.length;
                for (int i = 0; i < n; i++) {
                    int exp = n - i - 1;
                    vec.append(String.format("%.2f", a[i]));
                    if (exp > 0) {
                        vec.append("x");
                        if (exp > 1) {
                            vec.append("^").append(exp);
                        }
                    }
                    if (i < n - 1) {
                        vec.append(" + ");
                    }
                }
                displayJLabel.setText(vec.toString());
            }
        });

        JMenuItem devItem = new JMenuItem("Derivative");
        devItem.setMnemonic(13);
        cdiMenu.add(devItem);
        devItem.addActionListener(event -> {
            if (a != null) {
                StringBuilder vec = new StringBuilder();
                int n = a.length;
                for (int i = 0; i < n - 1; i++) {
                    int exp = n - i - 1;
                    double coef = a[i] * exp;
                    if (exp - 1 == 0) {
                        vec.append(String.format("%.2f + ", coef));
                    } else {
                        vec.append(String.format("%.2fx^%d + ", coef, exp - 1));
                    }
                }
                if (vec.length() > 3) {
                    vec.setLength(vec.length() - 3);
                }
                displayJLabel.setText(vec.toString());
            }
        });
        bar.add(cdiMenu);

        JMenu algesdMenu = new JMenu("ALGESD");
        algesdMenu.setMnemonic(11);

        JMenu ordM = new JMenu("Ordering");
        ordM.setMnemonic(12);
        algesdMenu.add(ordM);

        JMenuItem bubItem = new JMenuItem("Bubble");
        bubItem.setMnemonic(13);
        ordM.add(bubItem);
        bubItem.addActionListener(event -> {
            if (a != null) {
                BubbleSort sorter = new BubbleSort();
                double c[] = a.clone();
                sorter.sort(c);
                String vec = "";
                for (int i = 0; i < c.length; i++) {
                    vec += String.format("%.2f  ", c[i]);
                }
                displayJLabel.setText(vec);
            }
        });

        JMenuItem selItem = new JMenuItem("Selection");
        selItem.setMnemonic(14);
        ordM.add(selItem);
        selItem.addActionListener(event -> {
            if (a != null) {
                SelectionSort sorter = new SelectionSort();
                double c[] = a.clone();
                sorter.sort(c);
                String vec = "";
                for (int i = 0; i < c.length; i++) {
                    vec += String.format("%.2f  ", c[i]);
                }
                displayJLabel.setText(vec);
            }
        });

        JMenuItem insItem = new JMenuItem("Insertion");
        insItem.setMnemonic(15);
        ordM.add(insItem);
        insItem.addActionListener(event -> {
            if (a != null) {
                InsertionSort sorter = new InsertionSort();
                double c[] = a.clone();
                sorter.sort(c);
                String vec = "";
                for (int i = 0; i < c.length; i++) {
                    vec += String.format("%.2f  ", c[i]);
                }
                displayJLabel.setText(vec);
            }
        });

        JMenuItem qItem = new JMenuItem("Quick");
        qItem.setMnemonic(15);
        ordM.add(qItem);
        qItem.addActionListener(event -> {
            if (a != null) {
                QuickSort sorter = new QuickSort();
                double c[] = a.clone();
                sorter.sort(c);
                String vec = "";
                for (int i = 0; i < c.length; i++) {
                    vec += String.format("%.2f  ", c[i]);
                }
                displayJLabel.setText(vec);
            }
        });

        JMenuItem mgItem = new JMenuItem("Merge");
        mgItem.setMnemonic(16);
        ordM.add(mgItem);
        mgItem.addActionListener(event -> {
            if (a != null) {
                MergeSort sorter = new MergeSort();
                double c[] = a.clone();
                sorter.sort(c);
                String vec = "";
                for (int i = 0; i < c.length; i++) {
                    vec += String.format("%.2f  ", c[i]);
                }
                displayJLabel.setText(vec);
            }
        });

        JMenu sM = new JMenu("Search");
        sM.setMnemonic(17);
        algesdMenu.add(sM);

        JMenuItem liItem = new JMenuItem("Linear Iterative");
        liItem.setMnemonic(18);
        sM.add(liItem);
        liItem.addActionListener(event -> {
            if (a != null) {
                LinearISearch searcher = new LinearISearch();
                double k = DialogK.getValue(fr);
                int r = searcher.search(a, k);
                if (r == -1) {
                    displayJLabel.setText("Index not Found");
                } else {
                    String vec;
                    vec = String.format("Key at Index: %d", r);
                    displayJLabel.setText(vec);
                }
            }
        });

        JMenuItem lrItem = new JMenuItem("Linear Recursive");
        lrItem.setMnemonic(19);
        sM.add(lrItem);
        lrItem.addActionListener(event -> {
            if (a != null) {
                LinearRSearch searcher = new LinearRSearch();
                double k = DialogK.getValue(fr);
                int r = searcher.search(a, k, 0);
                if (r == -1) {
                    displayJLabel.setText("Index not Found");
                } else {
                    String vec;
                    vec = String.format("Key at Index: %d", r);
                    displayJLabel.setText(vec);
                }
            }
        });

        JMenuItem biItem = new JMenuItem("Binary Iterative");
        biItem.setMnemonic(20);
        sM.add(biItem);
        biItem.addActionListener(event -> {
            if (a != null) {
                double[] c = a.clone();
                sortArray(c, fr);
                BinaryISearch searcher = new BinaryISearch();
                double k = DialogK.getValue(fr);
                int r = searcher.search(c, k);
                if (r == -1) {
                    displayJLabel.setText("Index not Found");
                } else {
                    displayJLabel.setText(String.format("Key at Index: %d", r));
                }
            }
        });

        JMenuItem brItem = new JMenuItem("Binary Recursive");
        brItem.setMnemonic(21);
        sM.add(brItem);
        brItem.addActionListener(event -> {
            if (a != null) {
                double[] c = a.clone();
                sortArray(c, fr);
                BinaryRSearch searcher = new BinaryRSearch();
                double k = DialogK.getValue(fr);
                int r = searcher.search(c, k, 0, c.length - 1);
                if (r == -1) {
                    displayJLabel.setText("Index not Found");
                } else {
                    displayJLabel.setText(String.format("Key at Index: %d", r));
                }
            }
        });

        bar.add(algesdMenu);
        displayJLabel = new JLabel("Array Manager", SwingConstants.CENTER);
        displayJLabel.setForeground(Color.BLACK);
        displayJLabel.setFont(new Font("Serif", Font.PLAIN, 72));
        getContentPane().setBackground(Color.WHITE);
        add(displayJLabel, BorderLayout.CENTER);
    }

    private void sortArray(double[] array, JFrame fr) {
        String[] options = {"Bubble", "Selection", "Insertion", "Quick", "Merge"};
        int choice = JOptionPane.showOptionDialog(fr, "Choose sorting algorithm", "Sort Array", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        switch(choice){
            case 0 -> {
                BubbleSort sorter = new BubbleSort();
                sorter.sort(array);
            }
            case 1 -> {
                SelectionSort sorter = new SelectionSort();
                sorter.sort(array);
            }
            case 2 -> {
                InsertionSort sorter = new InsertionSort();
                sorter.sort(array);
            }
            case 3 -> {
                QuickSort sorter = new QuickSort();
                sorter.sort(array);
            }
            case 4 -> {
                MergeSort sorter = new MergeSort();
                sorter.sort(array);
            }
            default -> throw new IllegalStateException("Unexpected value: " + choice);
        }
    }
}